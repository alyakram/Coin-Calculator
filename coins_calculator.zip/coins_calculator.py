import numpy as np
import cv2

def get_radius(circles):
    radius =[]
    for coords in circles[0,:]:
        radius.append(coords[2])
    return radius

def av_pix(image, circles, size):
    av_value = []
    for coords in circles[0,:]:
        col = np.mean(image[coords[1]-size:coords[1]+size, coords[0]-size:coords[0]+size])
        av_value.append(col)
    return av_value            

image = cv2.imread('capstone.png',cv2.IMREAD_GRAYSCALE)
original_image = cv2.imread('capstone.png', 1)
image = cv2.blur(image, (5,5), 0)
circles = cv2.HoughCircles(image, cv2.HOUGH_GRADIENT, 0.9, 120, param1=50, param2=27,minRadius=50,maxRadius=130)
print(circles)
circles = np.uint16(np.around(circles))     #Round circles to int values
count = 1
for i in circles[0,:]:

    #draw the outer circle
    cv2.circle(original_image, (i[0], i[1]), i[2], (0, 255, 0), 2)
    #Draw the center of the circle
    cv2.circle(original_image, (i[0], i[1]), 2, (0,0,255), 3)
    # cv2.putText(original_image, str(count), (i[0], i[1]), cv2.FONT_HERSHEY_SIMPLEX, 2, (0,0,0), 2)
    count += 1

radii = get_radius(circles)
print(radii)    
    
bright_values = av_pix(image, circles, 20)
print(bright_values)    
    
values = []
for a,b in zip(bright_values, radii):
    if a > 150 and b > 110:
        values.append(10)
    elif a > 150 and b <= 110:
        values.append(5)
    elif a < 150 and b > 110:
        values.append(2)
    elif a < 150 and b < 110:
        values.append(1)
print(values)
count_2 = 0
for i in circles[0,:]:

    cv2.putText(original_image, str(values[count_2]) + 'p', (i[0],i[1]), cv2.FONT_HERSHEY_SIMPLEX, 2 , (0,0,0), 2)
    count_2 += 1
cv2.putText(original_image, 'ESTIMATED TOTAL VALUE' + str(sum(values)) + 'p', (200,100), cv2.FONT_HERSHEY_SIMPLEX, 1.3, 255)



    
    
    
cv2.imshow('Detected Coins', original_image)
cv2.waitKey(0)
cv2.destroyAllWindows()


